#include <stdio.h>
#include <stdlib.h>
#define cant 5
int main()
{
int leg[cant];
float sueldo [cant];
int edad[cant];
int i;

for(i=0; i<cant; i++)
{
    printf(" ingrese legajo \n");
    scanf("%d", &leg;
    printf(" el legajo es ", leg);

    printf(" ingrese el sueldo \n");
    scanf("%f", &sueldo);
    printf(" el sueldo es " sueldo);

    printf(" ingrese la edad \n");
    scanf("%d", &edad);
    printf(" la edad es " edad);
}

return 0;


}
