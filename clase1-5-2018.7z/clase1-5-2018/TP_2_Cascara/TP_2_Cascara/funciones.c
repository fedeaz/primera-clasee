#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "funciones.h"


void inicializarPersona(EPersona vec[], int tam)
{
       int i;
       for(i=0; i<tam; i++)
       {
           vec[i].estado = 0;
       }
}

int buscarLibre(EPersona vec[], int tam)
    {
        int indice = -1;
        int i;
        for(i=0 ;i<tam; i++)
        {
            if(vec[i].estado == 0)
            {
                    indice = 0;
                    break;
            }
        }
        return indice;
    }

int buscarPersona(EPersona vec[], int tam, int dni)
    {
        int indice = -1;
        int i;

        for(i=0; i<tam; i++)
        {
                if(vec[i].estado == 1 && vec[i].dni == dni)
                {printf("llega");
                    indice = i;
                    break;
                }
        }
        return indice;

    }

void mostrarPersona(EPersona per)
    {
        printf("%s   %4d   %4d \n", per.nombre, per.dni, per.edad);
    }


void alta(EPersona vec[],int tam)
{
    EPersona nuevaPersona;
    int indice;
    int estado;
    int dni = 0;

    system("cls");
    printf(" Agregar Persona\n\n");

    indice = buscarLibre(vec, tam);

    if(indice != -1)
    {
        printf("ingrese el DNI\n");
        scanf("%d", &dni);

        estado = buscarPersona(vec, tam, dni);
        printf("%d",estado);

       if(estado != -1)
       {
           printf("\n el DNI ya corresponde a una persona ");
           mostrarPersona(vec[estado]);
       }
       else
       {
           nuevaPersona.estado =1;
           nuevaPersona.dni = dni;

           printf(" ingrese el nombre\n");
           fflush(stdin);
           gets(nuevaPersona.nombre);

           printf("ingrese la edad");
           scanf("%d", &nuevaPersona.edad);

           vec[indice] = nuevaPersona;

           printf("la alta fue exitosa");
       }
    }
    else
    {
        printf("\n no hay lugar disponible\n");
    }
}


void baja(EPersona vec[],int tam)
{
    int dni;
    int encuentra;
    char confirmar;


    printf("ingrese el DNI\n");
    scanf("%d", &dni);

    encuentra = buscarPersona(vec,tam,dni);

    if(encuentra== -1)
    {
        printf("el DNI no corresponde a una persona\n");
    }
    else
    {
        mostrarPersona(vec[encuentra]);

        printf("quiere realizar la baja ? s/n \n");
        fflush(stdin);
        scanf("%c", &confirmar);

        if(confirmar == 's')
        {
            vec[encuentra].estado = 0;
            printf("la baja fue exitosa !! \n");
        }
        else
        {
            printf("baja cancelada \n");
        }
    }
}
