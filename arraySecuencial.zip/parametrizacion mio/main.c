#include <stdio.h>
#include <stdlib.h>
#define cant 5

int main()
{
int vec[cant], i;

for(i=0; i< cant; i++)
{
    printf(" ingrese ");
    scanf("%d", &vec[i]);
}

for(i=0; i<cant; i++)
{
    printf("\n%d", vec[i]);

}




}
