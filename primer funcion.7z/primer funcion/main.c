#include <stdio.h>
#include <stdlib.h>


void saludar( );
int main()
{
    saludar ();
    return 0;
}
void saludar( )
{
    printf("hola, que tal");
}
