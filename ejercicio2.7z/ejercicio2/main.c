#include <stdio.h>
#include <stdlib.h>

int main()
{
char nombre [41];
char localidad [41];

printf("nombre :");
fflush(stdin);  /*stdin limpia el escaner de entrada, siempre se pone antes del scanf, tambien se utiliza setbuf(stdin , null);*/
scanf("%s", nombre);   /*no lleva & por ser vector*/

printf("localidad :");
scanf("%s", localidad);

printf("usted se llama %s y vive en %s", nombre , localidad);
return 0;
}
