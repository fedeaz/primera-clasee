#include <stdio.h>
#include <stdlib.h>
#include <

int main()
{
    int flag=0, nro;
char dato[15];
printf("ingrese");
fflush(stdin);
scanf("%s",dato);

for(i=0;i<strlen(dato);i++)
{
    if(!isdigit(dato[i]))
    {
        flag = 1;
        break;
    }
}
if(flag==0){
nro=atoid(dato);
}




    return 0;
}
