#include <stdio.h>
#include <stdlib.h>

int main()
{
    //int numero;
    char letra;

    printf("ingrese una letra : ");

    scanf("%c" , &letra);

    printf("usted ingreso el caracter : %c" , letra);

    return 0;
}
