#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int id;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
}eAuto;

int main()
{
        FILE* f;
        int cant;
        eAuto* auto1;
        eAuto* auxAuto;
        int i=0;
        int tam = 20;

        auto1=(eAuto*)malloc(tam*sizeof(eAuto));


    f = fopen("MOCKA DATA.csv", "r");
    if(f==NULL)
    {
        printf("no se pudo abrir\n\n");
        exit(EXIT_FAILURE);
    }

    //
     while(!feof(f))
     {
         if(tam == i)
        {
            auxAuto = auto1;
            auxAuto =(eAuto*)realloc(auto1,(tam+20)*sizeof(eAuto));
            if(auxAuto ==NULL)
            {
                printf("no se pudo encontrar memoria\n");
                system("pause");
                exit(EXIT_FAILURE);
            }
            else
            {
                auto1 = auxAuto;
                tam=tam+20;
            }
        }
         cant = fscanf(f,"%d, %[^,], %[^,], %[^,], %d, %d,\n", &(auto1+i)->id,(auto1+i)->marca,(auto1+i)->modelo,(auto1+i)->color,&(auto1+i)->anio);

     if(cant !=5)
     {
         if(feof(f))
         {
             break;
         }
         else
         {
             printf("hubo un error\n");
             exit(EXIT_FAILURE);
         }
     }
         printf("%4d %16s %16s %16s %4d\n", (auto1+i)->id,(auto1+i)->marca,(auto1+i)->modelo,(auto1+i)->color,(auto1+i)->anio);

         i++;
    }

    free(auto1);
    return 0;
}
