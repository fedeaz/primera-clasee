#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int id;
    char marca[20];
    char modelo[20];
    char color[20];
    int anio;
}eAuto;

int main()
{
        FILE* f;
        int cant;
        eAuto auto1;

    f = fopen("MOCKA DATA.csv", "r");
    if(f==NULL)
    {
        printf("no se pudo abrir\n\n");
        exit(EXIT_FAILURE);
    }

    //
     while(!feof(f))
     {
         cant = fscanf(f,"%d, %[^,], %[^,], %[^,], %d, %d,\n", &auto1.id,auto1.marca,auto1.modelo,auto1.color,&auto1.anio);

     if(cant !=5)
     {
         if(feof(f))
         {
             break;
         }
         else
         {
             printf("hubo un error\m");
             exit(EXIT_FAILURE);
         }
     }
         printf("%4d %16s %16s %16s %4d\n", auto1.id,auto1.marca,auto1.modelo,auto1.color,auto1.anio);
    }


    return 0;
}
