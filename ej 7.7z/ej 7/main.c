#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
    int nota;
    int edad;
    char sexo;

    float promedio;
    int acumuladorNotas = 0;

    int notaBaja;
    char sexoBajo;

    int contadorVaronesMas10 = 0;

    int minEdad;
    char minSexo;
    int notaMin;

    int contadorMujer = 0;
    int notaMujer;
    int edadMujer;

    int vandera = 0;
    int i = 0;

    for(int i = 0; i<5 ; i++)
    {
        printf("ingrese la nota : ");
        scanf("%d", &nota);

        while(nota <0 || nota > 10)
        {
            printf("ingrese una nota valida : ");
            scanf("%d", &nota);
        }

        printf("ingrese la edad : ");
        scanf("%d", &edad);
        while(edad <=0)
        {
            printf("ingrese una edad valida : ");
            scanf("%d", &edad);
        }

        printf("ingrese el sexo : ");
        fflush(stdin);
        scanf("%c", &sexo);
        sexo = tolower(sexo);

        while(sexo !='m' && sexo != 'f')
        {
            printf("ingrese un sexo valido: ");
            fflush(stdin);
            scanf("%c", &sexo);
            sexo = tolower(sexo);
        }

        acumuladorNotas = acumuladorNotas + nota;


    if (nota < notaBaja || vandera == 0)
    {
        notaBaja = nota;
        sexoBajo = sexo;
    }

    if (edad < minEdad || vandera == 0)
    {
        minEdad = edad;
        minSexo = sexo;
        notaMin = nota;
        vandera = 1;
    }
    if (sexo == 'm' && edad >18 && nota >= 6)
    {
        contadorVaronesMas10 ++;
    }
    if (sexo == 'f' && contadorMujer == 0)
    {
        notaMujer = nota;
        edadMujer = edad;
        contadorMujer ++;
    }

    }

    promedio = (float) acumuladorNotas / 5;

    printf("El promedio de las notas es: %.2f", promedio);
    printf("La nota mas baja es: %.2f", notaBaja, sexoBajo);
    printf("La cantidad de varones menores de 18 y con nota mayor a 6 fue: %.2f", contadorVaronesMas10);
    printf("La edad del mas joven: %d su sexo: %c y su nota: %d", minEdad, minSexo, notaMin);

    if (contadorMujer == 0)
    {
        printf("No se ingreso ninguna mujer");
    }
    else
    {
        printf("Los deatos de la primer mujer ingresada: Nota: %d Edad %d", notaMujer, edadMujer);
    }
}
