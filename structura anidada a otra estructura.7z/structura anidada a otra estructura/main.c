#include <stdio.h>
#include <stdlib.h>
#define cant 5
typedef struct{
int dia,mes,anio;
    }eFecha;

typedef struct{

    char nombre[21];
    int legajo;
    float sueldo;
    char sexo;
    eFecha fechaN;
    }eEmpleado;



int main()
{
    eEmpleado emp[cant], aux ;
    //emp.nombre; //con el '.' se accede a nombre o sueldo o legajo etc...
   // emp.legajo;
  //  emp.fechaN.dia;
  int i=0;

    for(i =0; i<cant-1; i++)
    {
        for(int j=0; j<cant;j++)
        {
            if (emp[i].sueldo< emp[j].sueldo)
            {
                aux = emp[i];
                emp[i] = emp[j];
                emp[j] = aux;
            }
            else{ if(emp[i].sueldo==emp[j].sueldo)
            {
                if(strcmp(emp[i].nombre,emp[j].nombre)>0)
                {
                    aux=emp[i];
                    emp[i]=emp[j];
                    emp[j]=aux;
                }
            }
          }
        }
    }






    return 0;
}
